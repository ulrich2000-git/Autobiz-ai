-- ============================================
-- AutoBiz AI – Supabase SQL Schema
-- Run in: Supabase Dashboard > SQL Editor
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Users (extends Supabase auth.users) ──
CREATE TABLE IF NOT EXISTS public.users (
  id              UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  plan            TEXT DEFAULT 'free' CHECK (plan IN ('free','pro')),
  stripe_customer_id TEXT,
  subscription_id TEXT,
  usage           JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create user row on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.users (id, plan, usage)
  VALUES (NEW.id, 'free', '{}')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- ── WhatsApp Configurations ──
CREATE TABLE IF NOT EXISTS public.whatsapp_configs (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id         UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  business_name   TEXT,
  phone_number    TEXT,
  tone            TEXT DEFAULT 'professionnel',
  system_prompt   TEXT,
  active          BOOLEAN DEFAULT false,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── WhatsApp Messages ──
CREATE TABLE IF NOT EXISTS public.whatsapp_messages (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id         UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  from_number     TEXT NOT NULL,
  to_number       TEXT NOT NULL,
  message         TEXT NOT NULL,
  direction       TEXT CHECK (direction IN ('inbound','outbound')),
  status          TEXT DEFAULT 'received',
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_wa_messages_user ON public.whatsapp_messages(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wa_messages_contact ON public.whatsapp_messages(user_id, from_number);

-- ── Content Generations ──
CREATE TABLE IF NOT EXISTS public.content_generations (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id         UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  type            TEXT NOT NULL,
  sector          TEXT,
  tone            TEXT,
  objective       TEXT,
  keywords        TEXT,
  language        TEXT DEFAULT 'fr',
  content         TEXT NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_content_user ON public.content_generations(user_id, created_at DESC);

-- ── Sales Analyses ──
CREATE TABLE IF NOT EXISTS public.sales_analyses (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id         UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  period          TEXT,
  data_count      INTEGER DEFAULT 0,
  currency        TEXT DEFAULT 'EUR',
  analysis        JSONB NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sales_user ON public.sales_analyses(user_id, created_at DESC);

-- ── Row Level Security ──
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_generations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales_analyses ENABLE ROW LEVEL SECURITY;

-- Users: can only see/edit own row
CREATE POLICY "users_self" ON public.users FOR ALL USING (auth.uid() = id);

-- WhatsApp configs
CREATE POLICY "wa_config_self" ON public.whatsapp_configs FOR ALL USING (auth.uid() = user_id);

-- WhatsApp messages
CREATE POLICY "wa_messages_self" ON public.whatsapp_messages FOR ALL USING (auth.uid() = user_id);

-- Content generations
CREATE POLICY "content_self" ON public.content_generations FOR ALL USING (auth.uid() = user_id);

-- Sales analyses
CREATE POLICY "sales_self" ON public.sales_analyses FOR ALL USING (auth.uid() = user_id);

-- Service role bypass for webhook handlers
CREATE POLICY "service_role_bypass_users" ON public.users FOR ALL TO service_role USING (true);
CREATE POLICY "service_role_bypass_wa_config" ON public.whatsapp_configs FOR ALL TO service_role USING (true);
CREATE POLICY "service_role_bypass_wa_messages" ON public.whatsapp_messages FOR ALL TO service_role USING (true);
CREATE POLICY "service_role_bypass_content" ON public.content_generations FOR ALL TO service_role USING (true);
CREATE POLICY "service_role_bypass_sales" ON public.sales_analyses FOR ALL TO service_role USING (true);

-- ============================================
-- Done! Tables + RLS created successfully.
-- ============================================
