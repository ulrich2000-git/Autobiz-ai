# AutoBiz AI 🚀

**Plateforme SaaS d'automatisation business avec IA**

Chatbot WhatsApp intelligent · Générateur de contenu marketing · Analyse des ventes avec IA

## Stack

- **Frontend** : Next.js 14 + Tailwind CSS
- **Backend** : Serverless Functions (Netlify)
- **BDD** : Supabase (PostgreSQL)
- **Auth** : Supabase Auth (email + Google OAuth)
- **IA** : OpenAI GPT-4o-mini
- **WhatsApp** : Twilio API
- **Paiements** : Stripe

## Lancement rapide

```bash
# 1. Cloner / extraire le projet
cd autobiz-ai

# 2. Installer les dépendances
npm install

# 3. Variables d'environnement
cp .env.example .env.local
# → Remplir les valeurs dans .env.local

# 4. Base de données
# → Exécuter supabase-schema.sql dans Supabase SQL Editor

# 5. Lancer en développement
npm run dev
# → http://localhost:3000
```

## Déploiement

Voir [DEPLOYMENT.md](./DEPLOYMENT.md) pour le guide complet étape par étape.

## Fonctionnalités

| Feature | Gratuit | Pro |
|---------|---------|-----|
| Chatbot WhatsApp | 50 msg/mois | Illimité |
| Génération contenu | 10/mois | Illimité |
| Analyses ventes | 3/mois | Illimité |
| Support | Email | Prioritaire |

## Structure

```
pages/app/       → Dashboard (chatbot, contenu, ventes, settings, billing)
pages/api/       → API Routes serverless
components/      → UI Components réutilisables
lib/             → Supabase, OpenAI, Stripe, Quota
hooks/           → useAuth
styles/          → CSS global
```
