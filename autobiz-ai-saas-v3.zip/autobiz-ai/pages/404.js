import Head from 'next/head'
import Link from 'next/link'
import { Zap, ArrowLeft } from 'lucide-react'

export default function NotFound() {
  return (
    <>
      <Head><title>404 – AutoBiz AI</title></Head>
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center px-6">
        <div className="text-center">
          <div className="text-8xl font-black text-white/5 mb-4" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>404</div>
          <div className="w-16 h-16 bg-gradient-to-br from-sky-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Zap size={28} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
            Page introuvable
          </h1>
          <p className="text-white/40 mb-8">Cette page n&apos;existe pas ou a été déplacée.</p>
          <Link href="/" className="btn-primary">
            <ArrowLeft size={16} />
            Retour à l&apos;accueil
          </Link>
        </div>
      </div>
    </>
  )
}
