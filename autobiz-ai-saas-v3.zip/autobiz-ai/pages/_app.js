import '../styles/globals.css'
import { AuthProvider } from '../hooks/useAuth'
import { ToastProvider } from '../components/ui/Toast'

export default function App({ Component, pageProps }) {
  return (
    <AuthProvider>
      <ToastProvider>
        <Component {...pageProps} />
      </ToastProvider>
    </AuthProvider>
  )
}
