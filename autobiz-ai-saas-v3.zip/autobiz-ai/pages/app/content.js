import { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { useAuth } from '../../hooks/useAuth'
import DashboardLayout from '../../components/dashboard/Layout'
import { PenTool, Copy, RefreshCw, Sparkles, Check } from 'lucide-react'

const CONTENT_TYPES = [
  { value: 'social_post', label: '📱 Post réseaux sociaux' },
  { value: 'email', label: '📧 Email marketing' },
  { value: 'ad_copy', label: '📢 Texte publicitaire' },
  { value: 'blog_intro', label: '✍️ Introduction blog' },
]

const SECTORS = [
  'E-commerce', 'Restaurant / Food', 'Immobilier', 'Mode & Beauté', 
  'Tech & SaaS', 'Santé & Bien-être', 'Éducation', 'Finance', 
  'Voyage & Tourisme', 'Sport & Fitness', 'Autre'
]

const TONES = [
  'Professionnel', 'Amical', 'Persuasif', 'Informatif', 
  'Inspirant', 'Humoristique', 'Urgent', 'Luxueux'
]

export default function ContentPage() {
  const { user, session, loading } = useAuth()
  const router = useRouter()
  const [form, setForm] = useState({
    type: 'social_post', sector: 'E-commerce', tone: 'Professionnel',
    objective: '', keywords: '', language: 'fr'
  })
  const [content, setContent] = useState('')
  const [generating, setGenerating] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState('')
  const [history, setHistory] = useState([])

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login')
  }, [user, loading])

  useEffect(() => {
    if (session) fetchHistory()
  }, [session])

  const fetchHistory = async () => {
    const res = await fetch('/api/content/history', {
      headers: { Authorization: `Bearer ${session.access_token}` }
    })
    const data = await res.json()
    if (data.history) setHistory(data.history)
  }

  const handleGenerate = async () => {
    if (!form.objective) { setError('Indiquez un objectif'); return }
    setGenerating(true)
    setError('')
    setContent('')

    const res = await fetch('/api/content/generate', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}` 
      },
      body: JSON.stringify(form),
    })

    const data = await res.json()
    setGenerating(false)
    
    if (!res.ok) {
      setError(data.error || 'Erreur lors de la génération')
    } else {
      setContent(data.content)
      fetchHistory()
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (loading) return <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center"><div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" /></div>

  return (
    <>
      <Head><title>Contenu IA – AutoBiz AI</title></Head>
      <DashboardLayout>
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
              Générateur de Contenu IA
            </h1>
            <p className="text-white/40">Créez du contenu marketing engageant en quelques secondes</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Form */}
            <div className="card p-8">
              <h2 className="text-lg font-bold text-white mb-6" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Paramètres</h2>
              
              <div className="space-y-5">
                <div>
                  <label className="label">Type de contenu</label>
                  <div className="grid grid-cols-2 gap-2">
                    {CONTENT_TYPES.map(t => (
                      <button key={t.value} onClick={() => setForm({...form, type: t.value})}
                        className={`p-3 rounded-xl text-sm font-medium text-left transition-all ${
                          form.type === t.value 
                            ? 'bg-sky-500/20 border border-sky-500/40 text-sky-300' 
                            : 'bg-white/3 border border-white/10 text-white/50 hover:text-white hover:bg-white/8'
                        }`}>
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Secteur d&apos;activité</label>
                    <select className="input" value={form.sector} onChange={e => setForm({...form, sector: e.target.value})}>
                      {SECTORS.map(s => <option key={s} className="bg-[#1e293b]">{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="label">Ton</label>
                    <select className="input" value={form.tone} onChange={e => setForm({...form, tone: e.target.value})}>
                      {TONES.map(t => <option key={t} className="bg-[#1e293b]">{t}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="label">Objectif *</label>
                  <input className="input" placeholder="Ex: Augmenter les ventes de chaussures d'été"
                    value={form.objective} onChange={e => setForm({...form, objective: e.target.value})} />
                </div>

                <div>
                  <label className="label">Mots-clés (optionnel)</label>
                  <input className="input" placeholder="Ex: soldes, été, confort, style"
                    value={form.keywords} onChange={e => setForm({...form, keywords: e.target.value})} />
                </div>

                <div>
                  <label className="label">Langue</label>
                  <select className="input" value={form.language} onChange={e => setForm({...form, language: e.target.value})}>
                    <option value="fr" className="bg-[#1e293b]">🇫🇷 Français</option>
                    <option value="en" className="bg-[#1e293b]">🇬🇧 English</option>
                    <option value="es" className="bg-[#1e293b]">🇪🇸 Español</option>
                    <option value="ar" className="bg-[#1e293b]">🇸🇦 العربية</option>
                  </select>
                </div>

                {error && <p className="text-red-400 text-sm">{error}</p>}

                <button onClick={handleGenerate} disabled={generating}
                  className="btn-primary w-full justify-center disabled:opacity-50">
                  {generating ? (
                    <><RefreshCw size={16} className="animate-spin" /> Génération en cours...</>
                  ) : (
                    <><Sparkles size={16} /> Générer le contenu</>
                  )}
                </button>
              </div>
            </div>

            {/* Result */}
            <div className="space-y-4">
              <div className="card p-8 min-h-[300px] flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Résultat</h2>
                  {content && (
                    <button onClick={handleCopy} className="btn-secondary text-sm py-1.5">
                      {copied ? <><Check size={14} /> Copié !</> : <><Copy size={14} /> Copier</>}
                    </button>
                  )}
                </div>
                
                {generating ? (
                  <div className="flex-1 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-10 h-10 border-2 border-sky-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                      <p className="text-white/40 text-sm">L&apos;IA génère votre contenu...</p>
                    </div>
                  </div>
                ) : content ? (
                  <div className="flex-1 p-4 bg-white/3 rounded-xl border border-white/10 text-white/80 text-sm leading-relaxed whitespace-pre-wrap">
                    {content}
                  </div>
                ) : (
                  <div className="flex-1 flex items-center justify-center">
                    <div className="text-center">
                      <PenTool size={36} className="text-white/15 mx-auto mb-3" />
                      <p className="text-white/30 text-sm">Remplissez le formulaire et cliquez sur Générer</p>
                    </div>
                  </div>
                )}
              </div>

              {/* History */}
              {history.length > 0 && (
                <div className="card p-6">
                  <h3 className="text-sm font-bold text-white/60 uppercase tracking-wider mb-3">Historique récent</h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {history.slice(0, 5).map((item, i) => (
                      <button key={i} onClick={() => setContent(item.content)}
                        className="w-full text-left p-3 bg-white/3 hover:bg-white/8 rounded-xl transition-colors group">
                        <div className="flex items-center justify-between mb-1">
                          <span className="badge-blue text-xs">{CONTENT_TYPES.find(t => t.value === item.type)?.label || item.type}</span>
                          <span className="text-xs text-white/30">{new Date(item.created_at).toLocaleDateString('fr-FR')}</span>
                        </div>
                        <p className="text-white/50 text-xs line-clamp-2">{item.content}</p>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
