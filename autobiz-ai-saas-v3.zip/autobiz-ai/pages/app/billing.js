import { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { useAuth } from '../../hooks/useAuth'
import DashboardLayout from '../../components/dashboard/Layout'
import { CreditCard, Check, Zap, ArrowRight, ExternalLink } from 'lucide-react'

export default function BillingPage() {
  const { user, session, loading, userData, refetchUser } = useAuth()
  const router = useRouter()
  const [checkoutLoading, setCheckoutLoading] = useState(false)
  const [portalLoading, setPortalLoading] = useState(false)

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login')
  }, [user, loading])

  useEffect(() => {
    if (router.query.success) { refetchUser() }
  }, [router.query])

  const isPro = userData?.plan === 'pro'

  const handleUpgrade = async () => {
    setCheckoutLoading(true)
    const res = await fetch('/api/stripe/create-checkout', {
      method: 'POST',
      headers: { Authorization: `Bearer ${session.access_token}` }
    })
    const { url } = await res.json()
    if (url) window.location.href = url
    else setCheckoutLoading(false)
  }

  const handlePortal = async () => {
    setPortalLoading(true)
    const res = await fetch('/api/stripe/portal', {
      method: 'POST',
      headers: { Authorization: `Bearer ${session.access_token}` }
    })
    const { url } = await res.json()
    if (url) window.location.href = url
    else setPortalLoading(false)
  }

  const freeLimits = { 'Messages WhatsApp': '50/mois', 'Générations contenu': '10/mois', 'Analyses ventes': '3/mois' }
  const proLimits = { 'Messages WhatsApp': 'Illimité', 'Générations contenu': 'Illimité', 'Analyses ventes': 'Illimité', 'Support prioritaire': 'Inclus', 'Accès API': 'Inclus' }

  if (loading) return <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center"><div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" /></div>

  return (
    <>
      <Head><title>Facturation – AutoBiz AI</title></Head>
      <DashboardLayout>
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Facturation</h1>
            <p className="text-white/40">Gérez votre abonnement et vos paiements</p>
          </div>

          {router.query.success && (
            <div className="flex items-center gap-3 p-4 mb-6 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
              <Check size={20} />
              <p>Paiement confirmé ! Votre plan Pro est maintenant actif.</p>
            </div>
          )}

          {/* Current plan */}
          <div className="card p-8 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/40 text-sm mb-1">Plan actuel</p>
                <div className="flex items-center gap-3">
                  <h2 className="text-3xl font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                    {isPro ? 'Pro ⚡' : 'Gratuit'}
                  </h2>
                  {isPro && <span className="badge-blue">Actif</span>}
                </div>
                <p className="text-white/40 text-sm mt-1">{isPro ? '49€ / mois' : '0€ / mois'}</p>
              </div>
              {isPro ? (
                <button onClick={handlePortal} disabled={portalLoading}
                  className="btn-secondary">
                  <ExternalLink size={16} />
                  {portalLoading ? 'Chargement...' : 'Gérer l\'abonnement'}
                </button>
              ) : (
                <button onClick={handleUpgrade} disabled={checkoutLoading}
                  className="btn-primary">
                  <Zap size={16} />
                  {checkoutLoading ? 'Chargement...' : 'Passer au Pro'}
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-6 pt-6 border-t border-white/8">
              {Object.entries(isPro ? proLimits : freeLimits).map(([key, val]) => (
                <div key={key} className="flex items-center gap-2">
                  <Check size={14} className={isPro ? 'text-emerald-400' : 'text-white/40'} />
                  <div>
                    <p className="text-xs text-white/40">{key}</p>
                    <p className="text-sm font-medium text-white">{val}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upgrade CTA for free users */}
          {!isPro && (
            <div className="card p-8 bg-gradient-to-br from-sky-500/10 to-violet-500/10 border-sky-500/30">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <h3 className="text-2xl font-bold text-white mb-2" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                    Passez au Pro pour scaler
                  </h3>
                  <p className="text-white/50 max-w-md">
                    Débloquez tous les accès illimités et accélérez la croissance de votre business avec des outils IA sans restrictions.
                  </p>
                  <ul className="mt-4 space-y-2">
                    {['Messages WhatsApp illimités', 'Contenu marketing illimité', 'Analyses ventes illimitées', 'Support prioritaire'].map(f => (
                      <li key={f} className="flex items-center gap-2 text-sm text-white/70">
                        <Check size={14} className="text-sky-400" />{f}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="text-center flex-shrink-0">
                  <div className="text-5xl font-black text-white mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>49€</div>
                  <div className="text-white/40 text-sm mb-4">/ mois · Annulable à tout moment</div>
                  <button onClick={handleUpgrade} disabled={checkoutLoading}
                    className="btn-primary text-base px-8 py-3.5">
                    {checkoutLoading ? 'Redirection...' : 'Souscrire maintenant'}
                    <ArrowRight size={18} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </>
  )
}
