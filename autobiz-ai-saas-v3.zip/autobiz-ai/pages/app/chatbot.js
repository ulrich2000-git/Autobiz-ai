import { useState, useEffect, useCallback } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { useAuth } from '../../hooks/useAuth'
import DashboardLayout from '../../components/dashboard/Layout'
import { useToast } from '../../components/ui/Toast'
import { EmptyState } from '../../components/ui/EmptyState'
import {
  MessageSquare, Settings, Phone, Activity,
  RefreshCw, Wifi, WifiOff, Save, Bot, Clock
} from 'lucide-react'

const TONES = [
  { value: 'professionnel', label: '👔 Professionnel' },
  { value: 'amical', label: '😊 Amical & Chaleureux' },
  { value: 'fun', label: '🎉 Fun & Décontracté' },
  { value: 'formel', label: '🏛️ Formel' },
  { value: 'commercial', label: '💼 Commercial' },
]

function formatRelativeTime(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const m = Math.floor(diff / 60000)
  const h = Math.floor(diff / 3600000)
  const d = Math.floor(diff / 86400000)
  if (m < 1) return "À l'instant"
  if (m < 60) return `Il y a ${m}m`
  if (h < 24) return `Il y a ${h}h`
  return `Il y a ${d}j`
}

export default function ChatbotPage() {
  const { user, session, loading } = useAuth()
  const router = useRouter()
  const toast = useToast()
  const [config, setConfig] = useState({
    business_name: '', phone_number: '', tone: 'professionnel',
    system_prompt: '', active: false
  })
  const [messages, setMessages] = useState([])
  const [saving, setSaving] = useState(false)
  const [fetchingMsgs, setFetchingMsgs] = useState(false)
  const [activeTab, setActiveTab] = useState('config')
  const [stats, setStats] = useState({ total: 0, today: 0, contacts: 0 })
  const [selectedContact, setSelectedContact] = useState(null)

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login')
  }, [user, loading])

  useEffect(() => {
    if (session) { fetchConfig(); fetchMessages() }
  }, [session])

  const fetchConfig = async () => {
    try {
      const res = await fetch('/api/whatsapp/config', {
        headers: { Authorization: `Bearer ${session.access_token}` }
      })
      const { config: data } = await res.json()
      if (data) setConfig(data)
    } catch {}
  }

  const fetchMessages = useCallback(async () => {
    if (!session) return
    setFetchingMsgs(true)
    try {
      const res = await fetch('/api/whatsapp/messages?limit=100', {
        headers: { Authorization: `Bearer ${session.access_token}` }
      })
      const { messages: msgs, total } = await res.json()
      if (msgs) {
        setMessages(msgs)
        const todayCount = msgs.filter(m =>
          new Date(m.created_at).toDateString() === new Date().toDateString()
        ).length
        const contacts = new Set(
          msgs.filter(m => m.direction === 'inbound').map(m => m.from_number)
        ).size
        setStats({ total: total || 0, today: todayCount, contacts })
      }
    } catch {}
    setFetchingMsgs(false)
  }, [session])

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/whatsapp/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`
        },
        body: JSON.stringify(config),
      })
      if (res.ok) {
        toast({ message: 'Configuration sauvegardée !', type: 'success' })
      } else {
        toast({ message: 'Erreur lors de la sauvegarde', type: 'error' })
      }
    } catch {
      toast({ message: 'Erreur réseau', type: 'error' })
    }
    setSaving(false)
  }

  // Group messages by contact
  const groupedMessages = messages.reduce((acc, msg) => {
    const contact = msg.direction === 'inbound' ? msg.from_number : msg.to_number
    if (!acc[contact]) acc[contact] = []
    acc[contact].push(msg)
    return acc
  }, {})

  const contacts = Object.keys(groupedMessages)
  const selectedMessages = selectedContact ? groupedMessages[selectedContact] || [] : []

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <>
      <Head><title>Chatbot WhatsApp – AutoBiz AI</title></Head>
      <DashboardLayout>
        <div className="p-8 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                Chatbot WhatsApp
              </h1>
              <p className="text-white/40 mt-0.5">Assistant IA automatique pour vos clients</p>
            </div>
            <div className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-sm font-semibold border ${
              config.active
                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                : 'bg-white/5 text-white/40 border-white/10'
            }`}>
              {config.active ? <Wifi size={14}/> : <WifiOff size={14}/>}
              {config.active ? 'Bot actif' : 'Bot inactif'}
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: 'Messages totaux', value: stats.total, icon: MessageSquare, color: 'sky' },
              { label: "Aujourd'hui", value: stats.today, icon: Clock, color: 'violet' },
              { label: 'Contacts uniques', value: stats.contacts, icon: Phone, color: 'emerald' },
            ].map(({ label, value, icon: Icon, color }) => (
              <div key={label} className="bg-white/5 border border-white/10 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white/40 text-sm">{label}</span>
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center bg-${color}-500/10`}>
                    <Icon size={15} className={`text-${color}-400`} />
                  </div>
                </div>
                <div className="text-3xl font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                  {value}
                </div>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-white/5 rounded-xl border border-white/8 w-fit">
            {[
              { id: 'config', icon: Settings, label: 'Configuration' },
              { id: 'messages', icon: MessageSquare, label: `Messages (${stats.total})` },
            ].map(({ id, icon: Icon, label }) => (
              <button key={id} onClick={() => setActiveTab(id)}
                className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === id
                    ? 'bg-white/12 text-white shadow-sm'
                    : 'text-white/40 hover:text-white/70'
                }`}>
                <Icon size={15}/>{label}
              </button>
            ))}
          </div>

          {/* Config tab */}
          {activeTab === 'config' && (
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-7">
                <h2 className="text-lg font-bold text-white mb-6" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                  Configuration du bot
                </h2>
                <div className="space-y-5">
                  <div>
                    <label className="label">Nom de l&apos;entreprise</label>
                    <input className="input" placeholder="Ma Boutique"
                      value={config.business_name}
                      onChange={e => setConfig({...config, business_name: e.target.value})} />
                  </div>
                  <div>
                    <label className="label">Numéro WhatsApp Twilio</label>
                    <input className="input" placeholder="whatsapp:+14155238886"
                      value={config.phone_number}
                      onChange={e => setConfig({...config, phone_number: e.target.value})} />
                    <p className="text-xs text-white/25 mt-1.5">
                      Disponible dans votre console Twilio
                    </p>
                  </div>
                  <div>
                    <label className="label">Ton du chatbot</label>
                    <div className="grid grid-cols-1 gap-2">
                      {TONES.map(t => (
                        <button key={t.value}
                          onClick={() => setConfig({...config, tone: t.value})}
                          className={`text-left px-4 py-2.5 rounded-xl text-sm font-medium transition-all border ${
                            config.tone === t.value
                              ? 'bg-sky-500/15 border-sky-500/35 text-sky-300'
                              : 'bg-white/3 border-white/8 text-white/50 hover:text-white hover:bg-white/8'
                          }`}>
                          {t.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="label">Instructions personnalisées</label>
                    <textarea className="input resize-none" rows={5}
                      placeholder="Ex: Tu es un assistant pour une boutique de vêtements. Aide les clients à trouver leur taille, vérifier les stocks. Si la question dépasse tes compétences, dis : 'Je vais demander à mon équipe de vous rappeler.'"
                      value={config.system_prompt}
                      onChange={e => setConfig({...config, system_prompt: e.target.value})} />
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/3 rounded-xl border border-white/8">
                    <div>
                      <p className="text-white font-medium text-sm">Activer le chatbot</p>
                      <p className="text-white/35 text-xs mt-0.5">Répond automatiquement aux messages entrants</p>
                    </div>
                    <button
                      onClick={() => setConfig({...config, active: !config.active})}
                      className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${config.active ? 'bg-sky-500' : 'bg-white/15'}`}>
                      <div className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform duration-200 ${config.active ? 'translate-x-6' : 'translate-x-0'}`} />
                    </button>
                  </div>
                  <button onClick={handleSave} disabled={saving}
                    className="btn-primary w-full justify-center disabled:opacity-50">
                    <Save size={16}/>
                    {saving ? 'Sauvegarde...' : 'Sauvegarder la configuration'}
                  </button>
                </div>
              </div>

              {/* Setup guide */}
              <div className="space-y-4">
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
                  <h3 className="font-bold text-white mb-4" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                    🛠️ Guide de configuration
                  </h3>
                  <div className="space-y-4">
                    {[
                      { n: '1', title: 'Créez un compte Twilio', desc: 'Inscrivez-vous sur twilio.com et activez le Sandbox WhatsApp gratuit.' },
                      { n: '2', title: 'Configurez le webhook', desc: `Allez dans Twilio → Phone Numbers → votre numéro → Messaging → URL du webhook : [votre-app]/api/whatsapp/webhook` },
                      { n: '3', title: 'Renseignez vos credentials', desc: 'Ajoutez TWILIO_ACCOUNT_SID et TWILIO_AUTH_TOKEN dans vos variables Netlify.' },
                      { n: '4', title: 'Activez et testez', desc: "Remplissez ce formulaire, activez le bot, et envoyez un message WhatsApp à votre numéro Twilio." },
                    ].map(({ n, title, desc }) => (
                      <div key={n} className="flex gap-3">
                        <div className="w-6 h-6 rounded-full bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400 text-xs font-bold flex-shrink-0 mt-0.5">
                          {n}
                        </div>
                        <div>
                          <p className="text-white text-sm font-medium">{title}</p>
                          <p className="text-white/40 text-xs mt-0.5 leading-relaxed">{desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-sky-500/8 border border-sky-500/20 rounded-2xl p-5">
                  <div className="flex items-start gap-3">
                    <Bot size={18} className="text-sky-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sky-300 font-semibold text-sm">Tester le sandbox Twilio</p>
                      <p className="text-sky-400/60 text-xs mt-1 leading-relaxed">
                        Envoyez <code className="bg-sky-500/20 px-1 rounded">join [votre-mot-code]</code> au{' '}
                        <code className="bg-sky-500/20 px-1 rounded">+1 415 523 8886</code> sur WhatsApp pour rejoindre le sandbox de test.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Messages tab */}
          {activeTab === 'messages' && (
            <div className="grid lg:grid-cols-3 gap-5" style={{minHeight: 500}}>
              {/* Contacts list */}
              <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden">
                <div className="flex items-center justify-between p-4 border-b border-white/8">
                  <h3 className="font-semibold text-white text-sm">Conversations</h3>
                  <button onClick={fetchMessages} disabled={fetchingMsgs}
                    className="p-1.5 hover:bg-white/10 rounded-lg transition-colors">
                    <RefreshCw size={13} className={`text-white/40 ${fetchingMsgs ? 'animate-spin' : ''}`} />
                  </button>
                </div>
                <div className="overflow-y-auto" style={{maxHeight: 500}}>
                  {contacts.length === 0 ? (
                    <div className="p-6 text-center text-white/30 text-sm">
                      Aucune conversation
                    </div>
                  ) : contacts.map(contact => {
                    const msgs = groupedMessages[contact]
                    const last = msgs[0]
                    return (
                      <button key={contact}
                        onClick={() => setSelectedContact(contact)}
                        className={`w-full text-left p-4 border-b border-white/5 hover:bg-white/5 transition-colors ${selectedContact === contact ? 'bg-sky-500/10 border-l-2 border-l-sky-500' : ''}`}>
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-sky-500 to-violet-500 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                            {contact.replace('whatsapp:', '').slice(-2)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-white text-sm font-medium truncate">
                              {contact.replace('whatsapp:', '')}
                            </p>
                            <p className="text-white/35 text-xs truncate">{last?.message?.slice(0, 35)}…</p>
                          </div>
                          <span className="text-white/25 text-xs flex-shrink-0">
                            {formatRelativeTime(last?.created_at)}
                          </span>
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* Conversation view */}
              <div className="lg:col-span-2 bg-white/5 border border-white/10 rounded-2xl overflow-hidden flex flex-col">
                <div className="p-4 border-b border-white/8">
                  <h3 className="font-semibold text-white text-sm">
                    {selectedContact ? selectedContact.replace('whatsapp:', '') : 'Sélectionnez une conversation'}
                  </h3>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{maxHeight: 500}}>
                  {!selectedContact ? (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-white/25 text-sm">← Choisissez un contact</p>
                    </div>
                  ) : selectedMessages.slice().reverse().map((msg, i) => (
                    <div key={i} className={`flex ${msg.direction === 'outbound' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                        msg.direction === 'outbound'
                          ? 'bg-sky-500/20 text-sky-100 border border-sky-500/20 rounded-tr-sm'
                          : 'bg-white/8 text-white/80 border border-white/8 rounded-tl-sm'
                      }`}>
                        <p>{msg.message}</p>
                        <p className="text-[10px] mt-1 opacity-40 text-right">
                          {new Date(msg.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                {selectedContact && (
                  <div className="p-3 border-t border-white/8">
                    <p className="text-center text-xs text-white/25">
                      Les réponses sont envoyées automatiquement par l&apos;IA
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </>
  )
}
