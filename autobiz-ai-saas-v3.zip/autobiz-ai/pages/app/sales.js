import { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { useAuth } from '../../hooks/useAuth'
import DashboardLayout from '../../components/dashboard/Layout'
import { BarChart3, TrendingUp, AlertTriangle, Lightbulb, Upload, Plus, Trash2, Loader } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'

const SAMPLE_DATA = [
  { product: 'Produit A', revenue: 12500, units: 45, month: 'Jan' },
  { product: 'Produit B', revenue: 8200, units: 32, month: 'Jan' },
  { product: 'Produit A', revenue: 15300, units: 58, month: 'Fév' },
  { product: 'Produit B', revenue: 6100, units: 24, month: 'Fév' },
  { product: 'Produit A', revenue: 11200, units: 40, month: 'Mar' },
  { product: 'Produit B', revenue: 9800, units: 38, month: 'Mar' },
]

export default function SalesPage() {
  const { user, session, loading } = useAuth()
  const router = useRouter()
  const [salesData, setSalesData] = useState([{ product: '', revenue: '', units: '', month: '' }])
  const [analysis, setAnalysis] = useState(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [period, setPeriod] = useState('Q1 2025')
  const [error, setError] = useState('')
  const [useSample, setUseSample] = useState(false)

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login')
  }, [user, loading])

  const addRow = () => setSalesData([...salesData, { product: '', revenue: '', units: '', month: '' }])
  const removeRow = (i) => setSalesData(salesData.filter((_, idx) => idx !== i))
  const updateRow = (i, field, val) => {
    const updated = [...salesData]
    updated[i][field] = val
    setSalesData(updated)
  }

  const handleLoadSample = () => {
    setSalesData(SAMPLE_DATA)
    setUseSample(true)
  }

  const handleAnalyze = async () => {
    const dataToAnalyze = salesData.filter(r => r.product && r.revenue)
    if (dataToAnalyze.length === 0) { setError('Ajoutez au moins une ligne de données'); return }
    
    setAnalyzing(true)
    setError('')
    setAnalysis(null)

    const res = await fetch('/api/sales/analyze', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}` 
      },
      body: JSON.stringify({ salesData: dataToAnalyze, period }),
    })

    const data = await res.json()
    setAnalyzing(false)

    if (!res.ok) {
      setError(data.error)
    } else {
      setAnalysis(data.analysis)
    }
  }

  const chartData = salesData
    .filter(r => r.month && r.revenue)
    .reduce((acc, r) => {
      const existing = acc.find(a => a.month === r.month)
      if (existing) existing.revenue = (existing.revenue || 0) + Number(r.revenue)
      else acc.push({ month: r.month, revenue: Number(r.revenue) })
      return acc
    }, [])

  if (loading) return <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center"><div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" /></div>

  return (
    <>
      <Head><title>Analyse Ventes – AutoBiz AI</title></Head>
      <DashboardLayout>
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
              Analyse des Ventes IA
            </h1>
            <p className="text-white/40">Insights automatiques et recommandations stratégiques</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Data Input */}
            <div className="card p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Données de ventes</h2>
                <button onClick={handleLoadSample} className="text-xs text-sky-400 hover:text-sky-300 transition-colors">
                  Charger un exemple
                </button>
              </div>

              <div className="mb-4">
                <label className="label">Période analysée</label>
                <input className="input" placeholder="Ex: Q1 2025, Janvier 2025..." 
                  value={period} onChange={e => setPeriod(e.target.value)} />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-white/40 text-xs">
                      <th className="text-left pb-2 pr-2">Produit</th>
                      <th className="text-left pb-2 pr-2">CA (€)</th>
                      <th className="text-left pb-2 pr-2">Unités</th>
                      <th className="text-left pb-2 pr-2">Mois</th>
                      <th className="pb-2"></th>
                    </tr>
                  </thead>
                  <tbody className="space-y-2">
                    {salesData.map((row, i) => (
                      <tr key={i} className="gap-2">
                        <td className="pr-2 pb-2"><input className="input text-xs py-2" placeholder="Produit" value={row.product} onChange={e => updateRow(i, 'product', e.target.value)} /></td>
                        <td className="pr-2 pb-2"><input className="input text-xs py-2" type="number" placeholder="0" value={row.revenue} onChange={e => updateRow(i, 'revenue', e.target.value)} /></td>
                        <td className="pr-2 pb-2"><input className="input text-xs py-2" type="number" placeholder="0" value={row.units} onChange={e => updateRow(i, 'units', e.target.value)} /></td>
                        <td className="pr-2 pb-2"><input className="input text-xs py-2" placeholder="Jan" value={row.month} onChange={e => updateRow(i, 'month', e.target.value)} /></td>
                        <td className="pb-2">
                          <button onClick={() => removeRow(i)} className="p-2 hover:bg-red-500/10 rounded-lg transition-colors">
                            <Trash2 size={14} className="text-red-400" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <button onClick={addRow} className="btn-secondary text-sm py-2 w-full justify-center mt-3">
                <Plus size={14} /> Ajouter une ligne
              </button>

              {/* Mini chart preview */}
              {chartData.length > 1 && (
                <div className="mt-5 p-4 bg-white/3 rounded-xl">
                  <p className="text-xs text-white/40 mb-3">Aperçu</p>
                  <ResponsiveContainer width="100%" height={80}>
                    <BarChart data={chartData}>
                      <Bar dataKey="revenue" fill="#0ea5e9" radius={[3,3,0,0]} />
                      <XAxis dataKey="month" tick={{fill: '#ffffff40', fontSize: 10}} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{background: '#1e293b', border: '1px solid #334155', borderRadius: 8, color: '#fff'}} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}

              {error && <p className="text-red-400 text-sm mt-3">{error}</p>}

              <button onClick={handleAnalyze} disabled={analyzing}
                className="btn-primary w-full justify-center mt-5 disabled:opacity-50">
                {analyzing ? <><Loader size={16} className="animate-spin" /> Analyse IA en cours...</> : <><BarChart3 size={16} /> Analyser avec l&apos;IA</>}
              </button>
            </div>

            {/* Analysis Result */}
            <div className="space-y-4">
              {analyzing && (
                <div className="card p-12 text-center">
                  <div className="w-12 h-12 border-2 border-sky-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                  <p className="text-white/60">L&apos;IA analyse vos données...</p>
                  <p className="text-white/30 text-sm mt-1">Identification des tendances et recommandations</p>
                </div>
              )}

              {!analysis && !analyzing && (
                <div className="card p-12 text-center">
                  <BarChart3 size={40} className="text-white/20 mx-auto mb-3" />
                  <p className="text-white/40">Entrez vos données et lancez l&apos;analyse</p>
                </div>
              )}

              {analysis && (
                <>
                  {/* Score */}
                  <div className="card p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white/40 text-sm mb-1">Score de santé</p>
                        <p className="text-white text-sm leading-relaxed">{analysis.summary}</p>
                      </div>
                      <div className="w-20 h-20 relative flex-shrink-0">
                        <svg className="w-20 h-20 -rotate-90">
                          <circle cx="40" cy="40" r="32" fill="none" stroke="#1e293b" strokeWidth="6" />
                          <circle cx="40" cy="40" r="32" fill="none" 
                            stroke={analysis.score >= 70 ? '#10b981' : analysis.score >= 40 ? '#f59e0b' : '#ef4444'}
                            strokeWidth="6" strokeLinecap="round"
                            strokeDasharray={`${(analysis.score / 100) * 201} 201`} />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-2xl font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{analysis.score}</span>
                        </div>
                      </div>
                    </div>
                    {analysis.totalRevenue && (
                      <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-white/8">
                        <div>
                          <p className="text-xs text-white/30">CA Total</p>
                          <p className="text-white font-bold">{Number(analysis.totalRevenue).toLocaleString('fr-FR')} €</p>
                        </div>
                        {analysis.growthRate !== undefined && (
                          <div>
                            <p className="text-xs text-white/30">Croissance</p>
                            <p className={`font-bold ${analysis.growthRate >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                              {analysis.growthRate >= 0 ? '+' : ''}{analysis.growthRate}%
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Trends */}
                  {analysis.trends?.length > 0 && (
                    <div className="card p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <TrendingUp size={18} className="text-sky-400" />
                        <h3 className="font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Tendances détectées</h3>
                      </div>
                      <ul className="space-y-2">
                        {analysis.trends.map((t, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                            <span className="text-sky-400 mt-0.5">→</span>{t}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Problems */}
                  {analysis.problems?.length > 0 && (
                    <div className="card p-6 border-yellow-500/20 bg-yellow-500/5">
                      <div className="flex items-center gap-2 mb-4">
                        <AlertTriangle size={18} className="text-yellow-400" />
                        <h3 className="font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Points d&apos;attention</h3>
                      </div>
                      <ul className="space-y-2">
                        {analysis.problems.map((p, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                            <span className="text-yellow-400 mt-0.5">⚠</span>{p}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Recommendations */}
                  {analysis.recommendations?.length > 0 && (
                    <div className="card p-6 border-emerald-500/20 bg-emerald-500/5">
                      <div className="flex items-center gap-2 mb-4">
                        <Lightbulb size={18} className="text-emerald-400" />
                        <h3 className="font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Recommandations IA</h3>
                      </div>
                      <ul className="space-y-2">
                        {analysis.recommendations.map((r, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                            <span className="text-emerald-400 mt-0.5 font-bold">{i+1}.</span>{r}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
