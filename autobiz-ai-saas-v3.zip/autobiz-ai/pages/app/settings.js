import { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { useAuth } from '../../hooks/useAuth'
import DashboardLayout from '../../components/dashboard/Layout'
import { Settings, User, Key, Bell, Shield, Check } from 'lucide-react'

export default function SettingsPage() {
  const { user, session, loading, userData } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState('profile')
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login')
  }, [user, loading])

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  if (loading) return <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center"><div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" /></div>

  return (
    <>
      <Head><title>Paramètres – AutoBiz AI</title></Head>
      <DashboardLayout>
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Paramètres</h1>
            <p className="text-white/40">Gérez votre compte et vos préférences</p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar nav */}
            <div className="space-y-1">
              {[
                { id: 'profile', icon: User, label: 'Profil' },
                { id: 'api', icon: Key, label: 'Clés API' },
                { id: 'security', icon: Shield, label: 'Sécurité' },
              ].map(({ id, icon: Icon, label }) => (
                <button key={id} onClick={() => setActiveTab(id)}
                  className={`w-full sidebar-link ${activeTab === id ? 'active' : ''}`}>
                  <Icon size={16} />{label}
                </button>
              ))}
            </div>

            {/* Content */}
            <div className="lg:col-span-3">
              {activeTab === 'profile' && (
                <div className="card p-8">
                  <h2 className="text-xl font-bold text-white mb-6" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Informations du profil</h2>
                  <div className="flex items-center gap-5 mb-8">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-sky-500 to-violet-500 flex items-center justify-center text-2xl font-bold text-white">
                      {user?.email?.[0]?.toUpperCase()}
                    </div>
                    <div>
                      <p className="text-white font-medium">{user?.email?.split('@')[0]}</p>
                      <p className="text-white/40 text-sm">{user?.email}</p>
                      <span className={`badge mt-1 ${userData?.plan === 'pro' ? 'badge-blue' : 'badge-yellow'}`}>
                        Plan {userData?.plan === 'pro' ? 'Pro ⚡' : 'Gratuit'}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div><label className="label">Email</label><input className="input" value={user?.email || ''} disabled /></div>
                    <div><label className="label">Nom affiché</label><input className="input" placeholder="Votre nom" /></div>
                    <div><label className="label">Entreprise</label><input className="input" placeholder="Nom de votre entreprise" /></div>
                    <button onClick={handleSave} className="btn-primary">
                      {saved ? <><Check size={16} /> Sauvegardé !</> : 'Sauvegarder'}
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'api' && (
                <div className="card p-8">
                  <h2 className="text-xl font-bold text-white mb-2" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Clés API requises</h2>
                  <p className="text-white/40 text-sm mb-6">Ces clés sont configurées via les variables d&apos;environnement Netlify</p>
                  <div className="space-y-4">
                    {[
                      { name: 'OpenAI API Key', var: 'OPENAI_API_KEY', desc: 'Pour la génération de contenu et le chatbot' },
                      { name: 'Twilio Account SID', var: 'TWILIO_ACCOUNT_SID', desc: 'Pour l\'intégration WhatsApp' },
                      { name: 'Twilio Auth Token', var: 'TWILIO_AUTH_TOKEN', desc: 'Authentification Twilio' },
                      { name: 'Stripe Secret Key', var: 'STRIPE_SECRET_KEY', desc: 'Pour les paiements et abonnements' },
                    ].map(({ name, var: varName, desc }) => (
                      <div key={varName} className="p-4 bg-white/3 rounded-xl border border-white/10">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-white font-medium text-sm">{name}</p>
                          <code className="text-xs text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded">{varName}</code>
                        </div>
                        <p className="text-white/40 text-xs">{desc}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 p-4 bg-sky-500/10 border border-sky-500/20 rounded-xl">
                    <p className="text-sky-300 text-sm">
                      💡 Configurez ces variables dans <strong>Netlify → Site Settings → Environment Variables</strong>
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'security' && (
                <div className="card p-8">
                  <h2 className="text-xl font-bold text-white mb-6" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>Sécurité</h2>
                  <div className="space-y-4">
                    <div><label className="label">Nouveau mot de passe</label><input type="password" className="input" placeholder="••••••••" /></div>
                    <div><label className="label">Confirmer le mot de passe</label><input type="password" className="input" placeholder="••••••••" /></div>
                    <button onClick={handleSave} className="btn-primary">
                      {saved ? <><Check size={16} /> Mis à jour !</> : 'Changer le mot de passe'}
                    </button>
                  </div>
                  <div className="mt-8 pt-8 border-t border-white/8">
                    <h3 className="text-red-400 font-bold mb-2">Zone dangereuse</h3>
                    <p className="text-white/40 text-sm mb-4">La suppression du compte est irréversible.</p>
                    <button className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 rounded-xl text-sm font-medium transition-colors">
                      Supprimer mon compte
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
