import { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { useAuth } from '../../hooks/useAuth'
import DashboardLayout from '../../components/dashboard/Layout'
import QuickActions from '../../components/dashboard/QuickActions'
import ActivityFeed from '../../components/dashboard/ActivityFeed'
import { StatCard } from '../../components/ui/Card'
import { UsageBar } from '../../components/ui/Progress'
import { Badge } from '../../components/ui/Badge'
import {
  MessageSquare, PenTool, BarChart3, TrendingUp,
  Zap, ArrowRight, RefreshCw, Users
} from 'lucide-react'
import { PLANS } from '../../lib/stripe'
import Link from 'next/link'

export default function DashboardHome() {
  const { user, session, loading, userData } = useAuth()
  const router = useRouter()
  const [stats, setStats] = useState(null)
  const [activities, setActivities] = useState([])
  const [loadingStats, setLoadingStats] = useState(true)

  useEffect(() => {
    if (!loading && !user) router.push('/auth/login')
  }, [user, loading])

  useEffect(() => {
    if (session) loadDashboard()
  }, [session])

  const loadDashboard = async () => {
    setLoadingStats(true)
    try {
      const headers = { Authorization: `Bearer ${session.access_token}` }

      const [msgsRes, contentRes, salesRes] = await Promise.allSettled([
        fetch('/api/whatsapp/messages?limit=5', { headers }),
        fetch('/api/content/history', { headers }),
        fetch('/api/sales/history', { headers }),
      ])

      let totalMessages = 0, contentCount = 0, salesCount = 0
      const acts = []

      if (msgsRes.status === 'fulfilled' && msgsRes.value.ok) {
        const d = await msgsRes.value.json()
        totalMessages = d.total || 0
        ;(d.messages || []).slice(0, 3).forEach(m => acts.push({
          type: 'whatsapp',
          message: `Message ${m.direction === 'inbound' ? 'reçu de' : 'envoyé à'} ${(m.from_number || m.to_number || '').replace('whatsapp:', '')}`,
          detail: m.message?.slice(0, 60) + (m.message?.length > 60 ? '…' : ''),
          created_at: m.created_at,
        }))
      }

      if (contentRes.status === 'fulfilled' && contentRes.value.ok) {
        const d = await contentRes.value.json()
        contentCount = (d.history || []).length
        ;(d.history || []).slice(0, 2).forEach(c => acts.push({
          type: 'content',
          message: `Contenu généré : ${c.type?.replace('_', ' ')}`,
          detail: c.content?.slice(0, 60) + '…',
          created_at: c.created_at,
        }))
      }

      if (salesRes.status === 'fulfilled' && salesRes.value.ok) {
        const d = await salesRes.value.json()
        salesCount = (d.analyses || []).length
        ;(d.analyses || []).slice(0, 2).forEach(s => acts.push({
          type: 'sales',
          message: `Analyse ventes : ${s.period || 'Sans titre'}`,
          detail: s.analysis?.summary?.slice(0, 60) + '…',
          created_at: s.created_at,
        }))
      }

      // Sort activities by date
      acts.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))

      setStats({ totalMessages, contentCount, salesCount })
      setActivities(acts.slice(0, 8))
    } catch (e) {
      console.error(e)
    } finally {
      setLoadingStats(false)
    }
  }

  const isPro = userData?.plan === 'pro'
  const planKey = (userData?.plan || 'free').toUpperCase()
  const plan = PLANS[planKey] || PLANS.FREE
  const usage = userData?.usage || {}

  const getGreeting = () => {
    const h = new Date().getHours()
    if (h < 12) return 'Bonjour'
    if (h < 18) return 'Bon après-midi'
    return 'Bonsoir'
  }

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <>
      <Head><title>Dashboard – AutoBiz AI</title></Head>
      <DashboardLayout>
        <div className="p-8 space-y-8">

          {/* Welcome banner */}
          <div className="relative overflow-hidden rounded-2xl p-7 bg-gradient-to-br from-sky-500/15 via-violet-500/10 to-transparent border border-white/10">
            {/* Decorative glow */}
            <div className="absolute -top-10 -right-10 w-48 h-48 bg-sky-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="relative">
              <div className="flex items-start justify-between flex-wrap gap-4">
                <div>
                  <p className="text-white/40 text-sm mb-1">{getGreeting()} 👋</p>
                  <h1 className="text-3xl font-bold text-white mb-2" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                    {user?.email?.split('@')[0] || 'Utilisateur'}
                  </h1>
                  <p className="text-white/50 text-sm max-w-md">
                    Votre dashboard AutoBiz AI — automatisez, créez et analysez votre business.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {isPro ? (
                    <div className="flex items-center gap-2 px-4 py-2 bg-sky-500/20 border border-sky-500/40 rounded-xl">
                      <Zap size={15} className="text-sky-400" />
                      <span className="text-sky-300 font-semibold text-sm">Plan Pro actif</span>
                    </div>
                  ) : (
                    <Link href="/app/billing" className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-sky-500/20 to-violet-500/20 border border-sky-500/30 rounded-xl text-sky-300 font-semibold text-sm hover:from-sky-500/30 hover:to-violet-500/30 transition-all">
                      <Zap size={15} />
                      Passer au Pro
                      <ArrowRight size={14} />
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              label="Messages WhatsApp"
              value={loadingStats ? '…' : stats?.totalMessages ?? 0}
              icon={MessageSquare}
              color="sky"
              sublabel="Total envoyés & reçus"
            />
            <StatCard
              label="Contenus générés"
              value={loadingStats ? '…' : stats?.contentCount ?? 0}
              icon={PenTool}
              color="violet"
              sublabel="Ce mois"
            />
            <StatCard
              label="Analyses ventes"
              value={loadingStats ? '…' : stats?.salesCount ?? 0}
              icon={BarChart3}
              color="emerald"
              sublabel="Rapports créés"
            />
            <StatCard
              label="Plan"
              value={isPro ? 'Pro ⚡' : 'Gratuit'}
              icon={Zap}
              color={isPro ? 'sky' : 'yellow'}
              sublabel={isPro ? 'Accès illimité' : '→ Passer au Pro'}
            />
          </div>

          {/* Quick Actions + Activity */}
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white mb-4" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                  Accès rapide
                </h2>
                <QuickActions />
              </div>
            </div>

            {/* Right Column: usage + activity */}
            <div className="space-y-5">
              {/* Usage */}
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-white text-sm" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                    Utilisation du plan
                  </h3>
                  <Badge variant={isPro ? 'blue' : 'yellow'}>
                    {isPro ? 'Pro' : 'Gratuit'}
                  </Badge>
                </div>
                <div className="space-y-3">
                  {[
                    { key: 'whatsappMessages', label: 'WhatsApp' },
                    { key: 'contentGenerations', label: 'Contenu' },
                    { key: 'salesAnalyses', label: 'Analyses' },
                  ].map(({ key, label }) => (
                    <UsageBar
                      key={key}
                      label={label}
                      used={usage[key] || 0}
                      limit={plan.limits[key]}
                    />
                  ))}
                </div>
                {!isPro && (
                  <Link href="/app/billing"
                    className="mt-4 flex items-center justify-center gap-2 w-full py-2 text-xs font-semibold text-sky-400 bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/20 rounded-xl transition-colors">
                    <Zap size={12} />
                    Débloquer tout avec Pro
                  </Link>
                )}
              </div>

              {/* Activity Feed */}
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-white text-sm" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                    Activité récente
                  </h3>
                  <button onClick={loadDashboard} className="p-1.5 hover:bg-white/10 rounded-lg transition-colors">
                    <RefreshCw size={13} className="text-white/40" />
                  </button>
                </div>
                <ActivityFeed activities={activities} />
              </div>
            </div>
          </div>

          {/* Tips section for free users */}
          {!isPro && (
            <div className="grid md:grid-cols-3 gap-4">
              {[
                {
                  emoji: '💡',
                  title: 'Astuce : WhatsApp',
                  tip: 'Connectez Twilio Sandbox gratuitement pour tester votre chatbot avant de passer en production.',
                },
                {
                  emoji: '✍️',
                  title: 'Astuce : Contenu',
                  tip: 'Soyez précis dans vos objectifs — "augmenter les ventes de robes d\'été" > "vendre plus".',
                },
                {
                  emoji: '📊',
                  title: 'Astuce : Ventes',
                  tip: 'Importez au moins 3 mois de données pour obtenir des tendances significatives.',
                },
              ].map(({ emoji, title, tip }) => (
                <div key={title} className="p-5 bg-white/3 border border-white/8 rounded-2xl">
                  <div className="text-2xl mb-2">{emoji}</div>
                  <h4 className="text-white font-semibold text-sm mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{title}</h4>
                  <p className="text-white/40 text-xs leading-relaxed">{tip}</p>
                </div>
              ))}
            </div>
          )}

        </div>
      </DashboardLayout>
    </>
  )
}
