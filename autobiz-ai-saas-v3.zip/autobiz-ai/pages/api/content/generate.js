import { requireAuth } from '../../../lib/auth'
import { checkQuota, incrementUsage } from '../../../lib/quota'
import { createClient } from '@supabase/supabase-js'
import OpenAI from 'openai'

const PROMPTS = {
  social_post: ({ sector, tone, objective, keywords, language }) =>
    `Crée un post réseaux sociaux pour une entreprise du secteur "${sector}".
Ton: ${tone}. Objectif: ${objective}. Mots-clés: ${keywords || 'non spécifiés'}.
Langue: ${language}. Inclus des emojis pertinents et 3-5 hashtags.
Pour Twitter: max 280 caractères. Pour LinkedIn: 400-600 caractères (format LinkedIn long).
Génère les deux versions séparées par une ligne "---".`,

  email: ({ sector, tone, objective, keywords, language }) =>
    `Rédige un email marketing complet pour une entreprise du secteur "${sector}".
Ton: ${tone}. Objectif: ${objective}. Mots-clés: ${keywords || 'non spécifiés'}. Langue: ${language}.
Structure obligatoire:
OBJET: [objet accrocheur]
---
[Corps de l'email avec introduction, valeur, preuve sociale, CTA fort]
[Signature]`,

  ad_copy: ({ sector, tone, objective, keywords, language }) =>
    `Crée 3 variantes de textes publicitaires pour une entreprise du secteur "${sector}".
Ton: ${tone}. Objectif: ${objective}. Mots-clés: ${keywords || 'non spécifiés'}. Langue: ${language}.
Format pour chaque variante:
TITRE (max 30 car): ...
DESCRIPTION (max 90 car): ...
CTA: ...`,

  blog_intro: ({ sector, tone, objective, keywords, language }) =>
    `Rédige une introduction de blog SEO-optimisée pour une entreprise du secteur "${sector}".
Sujet: ${objective}. Mots-clés cibles: ${keywords || 'non spécifiés'}. Ton: ${tone}. Langue: ${language}.
150-200 mots. Commence par une accroche forte. Intègre naturellement les mots-clés.`,
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' })

  const user = await requireAuth(req, res)
  if (!user) return

  const quota = await checkQuota(user.id, 'contentGenerations')
  if (!quota.allowed) return res.status(429).json({ error: quota.reason })

  const { type = 'social_post', sector = 'E-commerce', tone = 'Professionnel', objective, keywords = '', language = 'fr' } = req.body

  if (!objective) return res.status(400).json({ error: 'Le champ "objectif" est requis' })

  try {
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

    const promptFn = PROMPTS[type] || PROMPTS.social_post
    const userPrompt = promptFn({ sector, tone, objective, keywords, language })

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'Tu es un expert en marketing digital et copywriting. Génère du contenu de haute qualité, engageant et axé sur la conversion. Réponds uniquement avec le contenu demandé, sans explications ni préambule.',
        },
        { role: 'user', content: userPrompt },
      ],
      max_tokens: 800,
      temperature: 0.75,
    })

    const content = completion.choices[0].message.content

    const db = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    )

    await db.from('content_generations').insert({
      user_id: user.id,
      type,
      sector,
      tone,
      objective,
      keywords,
      language,
      content,
    })

    await incrementUsage(user.id, 'contentGenerations')

    return res.status(200).json({
      content,
      remaining: quota.remaining !== undefined ? quota.remaining - 1 : -1,
    })
  } catch (error) {
    console.error('Content generation error:', error)
    return res.status(500).json({ error: `Erreur génération: ${error.message}` })
  }
}
