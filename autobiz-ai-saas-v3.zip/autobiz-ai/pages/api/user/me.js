import { requireAuth } from '../../../lib/auth'
import { createClient } from '@supabase/supabase-js'
import { PLANS } from '../../../lib/stripe'

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method Not Allowed' })

  const user = await requireAuth(req, res)
  if (!user) return

  const db = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  )

  let { data, error } = await db
    .from('users')
    .select('*')
    .eq('id', user.id)
    .single()

  // Auto-créer si absent
  if (error || !data) {
    const { data: newUser } = await db
      .from('users')
      .upsert({ id: user.id, plan: 'free', usage: {} }, { onConflict: 'id' })
      .select()
      .single()
    data = newUser
  }

  const planKey = (data?.plan || 'free').toUpperCase()
  const plan = PLANS[planKey] || PLANS.FREE

  return res.status(200).json({
    user: {
      ...data,
      email: user.email,
      planDetails: {
        name: plan.name,
        price: plan.price,
        limits: plan.limits,
      },
    },
  })
}
