import { requireAuth } from '../../../lib/auth'
import Stripe from 'stripe'
import { createClient } from '@supabase/supabase-js'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' })

  const user = await requireAuth(req, res)
  if (!user) return

  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2023-10-16' })
    const db = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    )

    const { data: userData } = await db
      .from('users')
      .select('stripe_customer_id')
      .eq('id', user.id)
      .single()

    if (!userData?.stripe_customer_id) {
      return res.status(400).json({ error: 'Aucun abonnement Stripe trouvé' })
    }

    const session = await stripe.billingPortal.sessions.create({
      customer: userData.stripe_customer_id,
      return_url: `${process.env.NEXT_PUBLIC_APP_URL}/app/billing`,
    })

    return res.status(200).json({ url: session.url })
  } catch (error) {
    console.error('Portal error:', error)
    return res.status(500).json({ error: error.message })
  }
}
