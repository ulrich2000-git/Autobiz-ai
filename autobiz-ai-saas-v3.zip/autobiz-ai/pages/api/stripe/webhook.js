import { stripe } from '../../../lib/stripe'
import { supabaseAdmin } from '../../../lib/supabase'

// ✅ Désactive le body parser pour Stripe webhook signature verification
export const config = {
  api: {
    bodyParser: false,
  },
}

async function getRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    req.on('data', (chunk) => chunks.push(chunk))
    req.on('end', () => resolve(Buffer.concat(chunks)))
    req.on('error', reject)
  })
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST')
    return res.status(405).end('Method Not Allowed')
  }

  const sig = req.headers['stripe-signature']
  if (!sig) return res.status(400).json({ error: 'Missing stripe-signature header' })

  let rawBody
  try {
    rawBody = await getRawBody(req)
  } catch (err) {
    return res.status(400).json({ error: 'Could not read body' })
  }

  let event
  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    )
  } catch (err) {
    console.error('Stripe webhook error:', err.message)
    return res.status(400).json({ error: `Webhook Error: ${err.message}` })
  }

  const db = supabaseAdmin()

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object
        const userId = session.metadata?.user_id
        if (userId) {
          await db
            .from('users')
            .update({
              plan: 'pro',
              subscription_id: session.subscription,
              updated_at: new Date().toISOString(),
            })
            .eq('id', userId)
        }
        break
      }
      case 'customer.subscription.updated': {
        const sub = event.data.object
        const status = sub.status
        if (status === 'active') {
          await db.from('users').update({ plan: 'pro' }).eq('subscription_id', sub.id)
        } else if (['canceled', 'unpaid', 'past_due'].includes(status)) {
          await db.from('users').update({ plan: 'free' }).eq('subscription_id', sub.id)
        }
        break
      }
      case 'customer.subscription.deleted': {
        const sub = event.data.object
        await db
          .from('users')
          .update({ plan: 'free', subscription_id: null })
          .eq('subscription_id', sub.id)
        break
      }
      default:
        console.log(`Unhandled event type: ${event.type}`)
    }
  } catch (err) {
    console.error('Webhook handler error:', err)
    return res.status(500).json({ error: 'Internal handler error' })
  }

  return res.status(200).json({ received: true })
}
