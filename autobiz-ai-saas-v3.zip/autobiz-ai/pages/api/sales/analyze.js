import { requireAuth } from '../../../lib/auth'
import { checkQuota, incrementUsage } from '../../../lib/quota'
import { createClient } from '@supabase/supabase-js'
import OpenAI from 'openai'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' })

  const user = await requireAuth(req, res)
  if (!user) return

  const quota = await checkQuota(user.id, 'salesAnalyses')
  if (!quota.allowed) return res.status(429).json({ error: quota.reason })

  const { salesData, period, currency = 'EUR' } = req.body

  if (!salesData || !Array.isArray(salesData) || salesData.length === 0) {
    return res.status(400).json({ error: 'salesData doit être un tableau non vide' })
  }

  // Limiter les données envoyées à l'API
  const dataToAnalyze = salesData.slice(0, 100)

  try {
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: `Tu es un expert analyste business et consultant en stratégie commerciale.
Analyse les données de ventes et génère des insights actionnables.
Réponds UNIQUEMENT avec un JSON valide (pas de markdown, pas de backticks), cette structure exacte:
{
  "summary": "résumé de 2 phrases max",
  "totalRevenue": 0,
  "growthRate": 0,
  "topProduct": "nom du produit",
  "trends": ["tendance 1", "tendance 2", "tendance 3"],
  "problems": ["problème 1", "problème 2"],
  "recommendations": ["recommandation 1", "recommandation 2", "recommandation 3"],
  "forecast": "prévision courte pour le prochain mois",
  "score": 75
}`,
        },
        {
          role: 'user',
          content: `Analyse ces données de ventes pour la période "${period || 'récente'}". Devise: ${currency}.\n\nDonnées: ${JSON.stringify(dataToAnalyze)}`,
        },
      ],
      max_tokens: 1000,
      temperature: 0.3,
    })

    const raw = completion.choices[0].message.content.trim()

    let analysis
    try {
      analysis = JSON.parse(raw)
    } catch {
      // Fallback si le JSON est malformé
      analysis = {
        summary: raw.slice(0, 200),
        totalRevenue: 0,
        growthRate: 0,
        topProduct: 'N/A',
        trends: [],
        problems: [],
        recommendations: ['Relancez l'analyse avec plus de données structurées'],
        forecast: 'Données insuffisantes',
        score: 50,
      }
    }

    const db = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    )

    await db.from('sales_analyses').insert({
      user_id: user.id,
      period,
      data_count: salesData.length,
      analysis,
      currency,
    })

    await incrementUsage(user.id, 'salesAnalyses')

    return res.status(200).json({
      analysis,
      remaining: quota.remaining !== undefined ? quota.remaining - 1 : -1,
    })
  } catch (error) {
    console.error('Sales analysis error:', error)
    return res.status(500).json({ error: `Erreur analyse: ${error.message}` })
  }
}
