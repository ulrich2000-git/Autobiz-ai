// ✅ Webhook WhatsApp/Twilio
// Ce fichier est exécuté UNIQUEMENT côté serveur (API Route)

export default async function handler(req, res) {
  if (req.method === 'GET') {
    // Vérification webhook WhatsApp Cloud API
    const mode = req.query['hub.mode']
    const token = req.query['hub.verify_token']
    const challenge = req.query['hub.challenge']
    if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
      return res.status(200).send(challenge)
    }
    return res.status(403).json({ error: 'Forbidden' })
  }

  if (req.method !== 'POST') {
    res.setHeader('Allow', ['GET', 'POST'])
    return res.status(405).json({ error: 'Method Not Allowed' })
  }

  try {
    const { createClient } = require('@supabase/supabase-js')
    const db = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    )

    const body = req.body
    const from = body.From
    const messageBody = body.Body
    const to = body.To

    if (!from || !messageBody || !to) {
      return res.status(200).send('<Response></Response>')
    }

    // Trouver la config associée à ce numéro
    const { data: config } = await db
      .from('whatsapp_configs')
      .select('*')
      .eq('phone_number', to)
      .single()

    if (!config || !config.active) {
      return res.status(200).send('<Response></Response>')
    }

    // Sauvegarder le message entrant
    await db.from('whatsapp_messages').insert({
      user_id: config.user_id,
      from_number: from,
      to_number: to,
      message: messageBody,
      direction: 'inbound',
      status: 'received',
    })

    // Générer réponse IA
    const OpenAI = require('openai').default
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

    const systemPrompt = config.system_prompt ||
      `Tu es un assistant service client pour ${config.business_name || 'cette entreprise'}. 
       Réponds de manière ${config.tone || 'professionnelle'}. Sois concis (max 3 phrases).`

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: messageBody },
      ],
      max_tokens: 300,
      temperature: 0.7,
    })

    const aiResponse = completion.choices[0].message.content

    // Envoyer via Twilio
    const twilio = require('twilio')
    const twilioClient = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN
    )
    await twilioClient.messages.create({
      body: aiResponse,
      from: to,
      to: from,
    })

    // Sauvegarder réponse sortante
    await db.from('whatsapp_messages').insert({
      user_id: config.user_id,
      from_number: to,
      to_number: from,
      message: aiResponse,
      direction: 'outbound',
      status: 'sent',
    })

    return res.status(200).send('<Response></Response>')
  } catch (error) {
    console.error('Webhook error:', error)
    // Toujours répondre 200 à Twilio pour éviter les retries infinis
    return res.status(200).send('<Response></Response>')
  }
}
