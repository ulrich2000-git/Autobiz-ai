import { requireAuth } from '../../../lib/auth'
import { createClient } from '@supabase/supabase-js'

export default async function handler(req, res) {
  const user = await requireAuth(req, res)
  if (!user) return

  const db = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  )

  if (req.method === 'GET') {
    const { data } = await db
      .from('whatsapp_configs')
      .select('*')
      .eq('user_id', user.id)
      .single()
    return res.status(200).json({ config: data || null })
  }

  if (req.method === 'POST') {
    const { business_name, phone_number, tone, system_prompt, active } = req.body

    const { data, error } = await db
      .from('whatsapp_configs')
      .upsert(
        {
          user_id: user.id,
          business_name: business_name || '',
          phone_number: phone_number || '',
          tone: tone || 'professionnel',
          system_prompt: system_prompt || '',
          active: Boolean(active),
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'user_id' }
      )
      .select()
      .single()

    if (error) return res.status(400).json({ error: error.message })
    return res.status(200).json({ config: data })
  }

  res.setHeader('Allow', ['GET', 'POST'])
  return res.status(405).json({ error: 'Method Not Allowed' })
}
