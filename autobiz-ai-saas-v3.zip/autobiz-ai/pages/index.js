import Head from 'next/head'
import Link from 'next/link'
import { 
  Zap, MessageSquare, PenTool, BarChart3, 
  Check, ArrowRight, Star, Shield, Globe,
  ChevronRight, Sparkles
} from 'lucide-react'

const features = [
  {
    icon: MessageSquare,
    color: 'from-sky-500 to-blue-600',
    title: 'Chatbot WhatsApp IA',
    description: 'Répondez à vos clients 24h/24 avec une IA qui comprend votre activité. Personnalisez le ton, gérez les conversations depuis un dashboard intuitif.',
  },
  {
    icon: PenTool,
    color: 'from-violet-500 to-purple-600',
    title: 'Générateur de Contenu',
    description: 'Posts réseaux sociaux, emails marketing, textes publicitaires. L\'IA génère du contenu optimisé conversion en quelques secondes.',
  },
  {
    icon: BarChart3,
    color: 'from-emerald-500 to-teal-600',
    title: 'Analyse des Ventes IA',
    description: 'Importez vos données et obtenez des insights actionnables : tendances, problèmes détectés, recommandations stratégiques précises.',
  },
]

const plans = [
  {
    name: 'Gratuit',
    price: '0€',
    period: '/mois',
    features: ['50 messages WhatsApp', '10 générations de contenu', '3 analyses de ventes', 'Dashboard basique'],
    cta: 'Commencer gratuitement',
    href: '/auth/signup',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: '49€',
    period: '/mois',
    features: ['Messages illimités', 'Contenu illimité', 'Analyses illimitées', 'Support prioritaire', 'Analytics avancés', 'API Access'],
    cta: 'Démarrer le Pro',
    href: '/auth/signup',
    highlighted: true,
    badge: 'Le plus populaire',
  },
]

const stats = [
  { value: '2 400+', label: 'Entreprises actives' },
  { value: '98%', label: 'Taux de satisfaction' },
  { value: '6x', label: 'Gain de productivité' },
  { value: '24/7', label: 'Support automatisé' },
]

export default function LandingPage() {
  return (
    <>
      <Head>
        <title>AutoBiz AI – Automatisez votre business avec l&apos;IA</title>
        <meta name="description" content="Chatbot WhatsApp IA, générateur de contenu marketing et analyse des ventes. La plateforme tout-en-un pour automatiser et faire croître votre business." />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen bg-[#0a0a0f]" style={{fontFamily: 'DM Sans, sans-serif'}}>
        
        {/* Noise texture overlay */}
        <div className="fixed inset-0 opacity-30 pointer-events-none" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
          backgroundSize: '200px',
        }} />

        {/* Ambient glow */}
        <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[900px] h-[600px] opacity-20 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse, #0ea5e9 0%, #6d28d9 40%, transparent 70%)' }} />

        {/* Navbar */}
        <nav className="relative z-50 flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-sky-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg shadow-sky-500/30">
              <Zap size={18} className="text-white" />
            </div>
            <span className="text-xl font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
              AutoBiz <span className="text-sky-400">AI</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {['Fonctionnalités', 'Tarifs', 'À propos'].map(item => (
              <a key={item} href={`#${item.toLowerCase()}`} className="text-white/50 hover:text-white text-sm font-medium transition-colors">
                {item}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <Link href="/auth/login" className="text-white/60 hover:text-white text-sm font-medium transition-colors px-4 py-2">
              Connexion
            </Link>
            <Link href="/auth/signup" className="btn-primary text-sm">
              Essai gratuit
              <ArrowRight size={15} />
            </Link>
          </div>
        </nav>

        {/* Hero */}
        <section className="relative z-10 text-center px-6 pt-24 pb-20 max-w-5xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-sky-500/10 border border-sky-500/30 rounded-full text-sky-300 text-sm font-medium mb-8">
            <Sparkles size={14} />
            Alimenté par GPT-4o · Twilio · Stripe
          </div>

          <h1 className="text-6xl md:text-7xl font-extrabold text-white leading-[1.05] mb-6 tracking-tight" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
            Automatisez votre<br/>
            <span className="gradient-text">business avec l&apos;IA</span>
          </h1>

          <p className="text-xl text-white/50 max-w-2xl mx-auto leading-relaxed mb-10">
            Chatbot WhatsApp intelligent, contenu marketing généré en secondes, analyse de ventes avec recommandations IA. Tout ce dont vous avez besoin pour scaler.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/auth/signup" className="btn-primary text-base px-7 py-3.5">
              Démarrer gratuitement
              <ArrowRight size={18} />
            </Link>
            <Link href="/auth/login" className="btn-secondary text-base px-7 py-3.5">
              Voir la démo
            </Link>
          </div>

          <p className="text-white/30 text-sm mt-6">Aucune carte bancaire requise · Gratuit pour toujours</p>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 pt-12 border-t border-white/8">
            {stats.map(({ value, label }) => (
              <div key={label} className="text-center">
                <div className="text-3xl font-bold gradient-text mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{value}</div>
                <div className="text-white/40 text-sm">{label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Features */}
        <section id="fonctionnalités" className="relative z-10 px-6 py-24 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
              Trois outils. Un seul dashboard.
            </h2>
            <p className="text-white/40 text-lg max-w-xl mx-auto">
              Tout ce qu&apos;il faut pour automatiser, créer et analyser — sans compétences techniques.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {features.map(({ icon: Icon, color, title, description }) => (
              <div key={title} className="card p-8 group hover:border-white/20 transition-all duration-300 hover:-translate-y-1">
                <div className={`w-12 h-12 bg-gradient-to-br ${color} rounded-2xl flex items-center justify-center mb-6 shadow-lg`}>
                  <Icon size={22} className="text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{title}</h3>
                <p className="text-white/50 leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section className="relative z-10 px-6 py-24 bg-white/2 border-y border-white/5">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-white mb-16" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
              Prêt en 3 minutes
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { n: '01', title: 'Créez votre compte', desc: 'Inscription en 30 secondes, aucune carte requise.' },
                { n: '02', title: 'Connectez vos outils', desc: 'Liez WhatsApp, configurez votre IA en quelques clics.' },
                { n: '03', title: 'Automatisez et scalez', desc: 'Votre business tourne en automatique. Vous focalisez sur la croissance.' },
              ].map(({ n, title, desc }) => (
                <div key={n} className="relative">
                  <div className="text-7xl font-black text-white/5 mb-4" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{n}</div>
                  <h3 className="text-xl font-bold text-white mb-2" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{title}</h3>
                  <p className="text-white/40">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section id="tarifs" className="relative z-10 px-6 py-24 max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
              Des tarifs simples et transparents
            </h2>
            <p className="text-white/40 text-lg">Commencez gratuitement, évoluez selon vos besoins.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {plans.map(({ name, price, period, features: planFeatures, cta, href, highlighted, badge }) => (
              <div key={name} className={`relative card p-8 ${highlighted ? 'border-sky-500/50 shadow-xl shadow-sky-500/10 bg-sky-500/5' : ''}`}>
                {badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="badge-blue text-xs px-3 py-1">{badge}</span>
                  </div>
                )}
                <div className="mb-6">
                  <h3 className="text-xl font-bold text-white mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-black text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{price}</span>
                    <span className="text-white/40">{period}</span>
                  </div>
                </div>
                <ul className="space-y-3 mb-8">
                  {planFeatures.map(f => (
                    <li key={f} className="flex items-center gap-3 text-white/70 text-sm">
                      <Check size={16} className="text-emerald-400 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link href={href} className={highlighted ? 'btn-primary w-full justify-center' : 'btn-secondary w-full justify-center'}>
                  {cta}
                </Link>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="relative z-10 px-6 py-24">
          <div className="max-w-3xl mx-auto text-center">
            <div className="card p-12 bg-gradient-to-br from-sky-500/10 to-violet-500/10 border-sky-500/20">
              <h2 className="text-4xl font-bold text-white mb-4" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
                Prêt à automatiser votre business ?
              </h2>
              <p className="text-white/50 text-lg mb-8">
                Rejoignez 2400+ entrepreneurs qui font confiance à AutoBiz AI.
              </p>
              <Link href="/auth/signup" className="btn-primary text-base px-8 py-4 inline-flex">
                Démarrer gratuitement
                <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="relative z-10 border-t border-white/8 px-6 py-10">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-gradient-to-br from-sky-500 to-violet-600 rounded-lg flex items-center justify-center">
                <Zap size={13} className="text-white" />
              </div>
              <span className="font-bold text-white text-sm" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>AutoBiz AI</span>
            </div>
            <p className="text-white/30 text-sm">© 2025 AutoBiz AI. Tous droits réservés.</p>
            <div className="flex items-center gap-4 text-white/30 text-sm">
              <a href="#" className="hover:text-white transition-colors">Confidentialité</a>
              <a href="#" className="hover:text-white transition-colors">CGU</a>
              <a href="#" className="hover:text-white transition-colors">Contact</a>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}
