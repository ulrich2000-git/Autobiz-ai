# 🚀 AutoBiz AI — Guide de Déploiement Netlify (Version Corrigée)

---

## ⚡ Pourquoi l'erreur se produisait

L'erreur `@netlify/plugin-nextjs failed` avait **2 causes combinées** :

1. **`@netlify/plugin-nextjs` était dans `package.json`** → il ne doit être QUE dans `netlify.toml`
2. **Le "Publish directory" était mal configuré dans l'UI Netlify** → doit être exactement `.next`

Next.js est pleinement supporté par Netlify via [OpenNext](https://opennext.js.org/).
Pas besoin de changer de framework.

---

## Étape 1 — Supabase

### 1.1 Créer le projet
1. [supabase.com](https://supabase.com) → **New Project**
2. Région : **Europe West** (Frankfurt)
3. Attendre ~2 min

### 1.2 Récupérer les clés
**Project Settings → API** :
```
NEXT_PUBLIC_SUPABASE_URL      = https://xxxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJ...  (anon public)
SUPABASE_SERVICE_ROLE_KEY     = eyJ...  (service_role — garder secret)
```

### 1.3 Créer les tables
1. **SQL Editor → New Query**
2. Coller le contenu de `supabase-schema.sql`
3. Cliquer **Run** → attendre "Success"

### 1.4 Activer l'auth Email
**Authentication → Providers → Email** → activé par défaut ✅

### 1.5 Google OAuth (optionnel)
1. [console.cloud.google.com](https://console.cloud.google.com) → **Credentials → Create OAuth 2.0 Client**
2. Redirect URI : `https://[ref].supabase.co/auth/v1/callback`
3. Supabase → **Authentication → Providers → Google** → coller Client ID + Secret

---

## Étape 2 — OpenAI

1. [platform.openai.com](https://platform.openai.com) → **API Keys → Create new secret key**
2. Copier : `sk-proj-...` → `OPENAI_API_KEY`
3. **Billing → Add credit** → minimum $5 pour tester
4. Modèle utilisé : `gpt-4o-mini` (~$0.002 par génération)

---

## Étape 3 — Twilio / WhatsApp

### Sandbox gratuit (recommandé pour démarrer)
1. [twilio.com](https://twilio.com) → Compte gratuit
2. Console → **Messaging → Try it out → Send a WhatsApp message**
3. Suivre les instructions pour rejoindre le sandbox

### Credentials
**Console → Account Info** :
```
TWILIO_ACCOUNT_SID  = ACxxxxxxxx...
TWILIO_AUTH_TOKEN   = xxxxxxxx...
TWILIO_WHATSAPP_FROM = whatsapp:+14155238886
```

### Configurer le webhook (après déploiement)
1. Console → **Phone Numbers → Manage → Active numbers** → votre numéro
2. **Messaging → A Message Comes In** :
   - URL : `https://[votre-app].netlify.app/api/whatsapp/webhook`
   - Method : POST
3. Sauvegarder

---

## Étape 4 — Stripe

### Clés API
**Developers → API Keys** :
```
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_test_...
STRIPE_SECRET_KEY                  = sk_test_...
```

### Créer le produit Pro
1. **Products → Add Product**
2. Nom : `AutoBiz AI Pro` / Prix : `49€` / Recurring Monthly
3. Copier le **Price ID** → `STRIPE_PRO_PRICE_ID = price_...`

### Webhook Stripe (après déploiement)
1. **Developers → Webhooks → Add endpoint**
2. URL : `https://[votre-app].netlify.app/api/stripe/webhook`
3. Events : `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`
4. Copier le **Signing secret** → `STRIPE_WEBHOOK_SECRET = whsec_...`

### Activer le Customer Portal
**Settings → Billing → Customer Portal → Save**

---

## Étape 5 — Variables d'environnement (`.env.local`)

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# OpenAI
OPENAI_API_KEY=sk-proj-...

# Twilio
TWILIO_ACCOUNT_SID=ACxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxx
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
WHATSAPP_VERIFY_TOKEN=mon-token-secret-perso

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRO_PRICE_ID=price_...

# App
NEXT_PUBLIC_APP_URL=https://votre-app.netlify.app
```

---

## Étape 6 — Déploiement Netlify ✅

### 6.1 Pousser sur GitHub
```bash
cd autobiz-ai
git init
git add .
git commit -m "feat: AutoBiz AI"
git remote add origin https://github.com/vous/autobiz-ai.git
git branch -M main
git push -u origin main
```

### 6.2 Importer sur Netlify
1. [app.netlify.com](https://app.netlify.com) → **Add new site → Import an existing project**
2. **GitHub** → autoriser → sélectionner `autobiz-ai`

### 6.3 ⚠️ Build Settings — CRITIQUE

> C'est ici que l'erreur se produisait. Vérifier **chaque champ** :

| Champ | Valeur |
|-------|--------|
| **Base directory** | *(laisser VIDE)* |
| **Build command** | `npm run build` |
| **Publish directory** | `.next` |
| **Functions directory** | *(laisser vide)* |

> Si **Publish directory** est vide, `/` ou `.` → erreur `@netlify/plugin-nextjs`

### 6.4 Ajouter les variables d'environnement
Avant de déployer : **Advanced → New variable** pour chacune des variables de l'Étape 5.

> 💡 Pour `NEXT_PUBLIC_APP_URL` : mettre une URL provisoire comme `https://temp.netlify.app`
> et la corriger après le 1er deploy avec la vraie URL.

### 6.5 Déployer
**Deploy site** → attendre 3-5 minutes ✅

### 6.6 Après le premier déploiement
1. Copier l'URL générée (ex: `https://whimsical-fox-123.netlify.app`)
2. **Environment Variables** → mettre à jour `NEXT_PUBLIC_APP_URL`
3. Mettre à jour l'URL dans Stripe Webhook
4. Mettre à jour l'URL dans Twilio Webhook
5. **Deploys → Trigger deploy → Deploy site**

---

## Étape 7 — Domaine personnalisé (optionnel)

1. **Domain Management → Add custom domain** → ex: `autobizai.com`
2. Configurer les DNS (A record ou CNAME vers Netlify)
3. HTTPS automatique via Let's Encrypt
4. Mettre à jour `NEXT_PUBLIC_APP_URL`, Stripe et Twilio avec le nouveau domaine

---

## Checklist de vérification post-déploiement ✅

```
[ ] https://votre-app.netlify.app  → Landing page s'affiche
[ ] /auth/signup                   → Inscription fonctionne (email reçu)
[ ] /auth/login                    → Connexion fonctionne
[ ] /app                           → Dashboard s'affiche
[ ] /app/content                   → Génération IA fonctionne
[ ] /app/sales → "Charger exemple" → Analyse IA fonctionne
[ ] /app/chatbot                   → Config se sauvegarde
[ ] /app/billing                   → Bouton Pro → redirige Stripe
[ ] Webhook Stripe                 → Tester avec Stripe CLI
[ ] WhatsApp                       → Message test → réponse auto
```

---

## Résolution d'erreurs

### ❌ `@netlify/plugin-nextjs failed` + publish directory
→ **UI Netlify** : Site Configuration → Build & Deploy → Publish directory = `.next`
→ **Ne pas** mettre `@netlify/plugin-nextjs` dans `package.json` (déjà corrigé)

### ❌ Variables d'env manquantes après deploy
→ Netlify → Environment Variables → ajouter → **Trigger redeploy**
→ Les variables sont lues au **moment du build**, pas à chaud

### ❌ `Invalid login credentials`
→ Supabase → Authentication → Users → vérifier que le compte existe et est confirmé
→ Désactiver "Email confirmation" dans Supabase pour les tests : Authentication → Settings

### ❌ `No such price` (Stripe)
→ Vérifier que `STRIPE_PRO_PRICE_ID` correspond au bon mode (test vs live)
→ Les clés `pk_test_` + `sk_test_` doivent être du même mode

### ❌ WhatsApp ne répond pas
→ Twilio Console → Monitor → Logs → Errors
→ Vérifier l'URL du webhook et que le bot est **activé** dans `/app/chatbot`

### ❌ `npm ERR! peer dep conflict`
→ Le `.npmrc` avec `legacy-peer-deps=true` et `NPM_FLAGS` dans `netlify.toml` gèrent ça

---

## Passage en production (Stripe Live)

```env
# Remplacer dans Netlify → Environment Variables :
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_SECRET_KEY=sk_live_...
# Recréer le webhook Stripe en mode Live → nouvelle STRIPE_WEBHOOK_SECRET
STRIPE_WEBHOOK_SECRET=whsec_...
```

Puis Trigger redeploy.
