export function Card({ children, className = '', glow = false, padding = true }) {
  return (
    <div className={`bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm ${glow ? 'shadow-xl shadow-black/30' : ''} ${padding ? 'p-6' : ''} ${className}`}>
      {children}
    </div>
  )
}

export function StatCard({ label, value, icon: Icon, trend, color = 'sky', sublabel }) {
  const colors = {
    sky: 'text-sky-400 bg-sky-500/10',
    emerald: 'text-emerald-400 bg-emerald-500/10',
    violet: 'text-violet-400 bg-violet-500/10',
    yellow: 'text-yellow-400 bg-yellow-500/10',
    red: 'text-red-400 bg-red-500/10',
  }
  return (
    <Card className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-white/40 text-sm">{label}</span>
        {Icon && (
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${colors[color]}`}>
            <Icon size={17} />
          </div>
        )}
      </div>
      <div>
        <div className="text-3xl font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{value}</div>
        {sublabel && <p className="text-white/30 text-xs mt-0.5">{sublabel}</p>}
      </div>
      {trend !== undefined && (
        <div className={`flex items-center gap-1 text-xs font-medium ${trend >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
          <span>{trend >= 0 ? '↑' : '↓'}</span>
          <span>{Math.abs(trend)}% vs mois dernier</span>
        </div>
      )}
    </Card>
  )
}
