export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      {Icon && (
        <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-4">
          <Icon size={28} className="text-white/20" />
        </div>
      )}
      <h3
        className="text-white font-semibold mb-2"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif' }}
      >
        {title}
      </h3>
      {description && (
        <p className="text-white/40 text-sm max-w-xs leading-relaxed">{description}</p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </div>
  )
}

export default EmptyState
