import { useState, useEffect, createContext, useContext, useCallback } from 'react'
import { CheckCircle, XCircle, AlertCircle, X, Info } from 'lucide-react'

const ToastContext = createContext(null)

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])

  const addToast = useCallback(({ message, type = 'info', duration = 4000 }) => {
    const id = Math.random().toString(36).slice(2)
    setToasts(prev => [...prev, { id, message, type }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), duration)
  }, [])

  const remove = (id) => setToasts(prev => prev.filter(t => t.id !== id))

  return (
    <ToastContext.Provider value={addToast}>
      {children}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full">
        {toasts.map(toast => (
          <Toast key={toast.id} {...toast} onClose={() => remove(toast.id)} />
        ))}
      </div>
    </ToastContext.Provider>
  )
}

function Toast({ message, type, onClose }) {
  const config = {
    success: { icon: CheckCircle, color: 'text-emerald-400', bg: 'border-emerald-500/30 bg-emerald-500/10' },
    error:   { icon: XCircle,    color: 'text-red-400',     bg: 'border-red-500/30 bg-red-500/10' },
    warning: { icon: AlertCircle,color: 'text-yellow-400',  bg: 'border-yellow-500/30 bg-yellow-500/10' },
    info:    { icon: Info,       color: 'text-sky-400',     bg: 'border-sky-500/30 bg-sky-500/10' },
  }
  const { icon: Icon, color, bg } = config[type] || config.info
  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl border backdrop-blur-sm shadow-xl ${bg} animate-in slide-in-from-right duration-300`}>
      <Icon size={18} className={`${color} flex-shrink-0 mt-0.5`} />
      <p className="text-white/80 text-sm flex-1">{message}</p>
      <button onClick={onClose} className="text-white/30 hover:text-white transition-colors">
        <X size={15} />
      </button>
    </div>
  )
}

export const useToast = () => useContext(ToastContext)
