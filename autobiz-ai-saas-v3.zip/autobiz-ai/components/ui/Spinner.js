export function Spinner({ size = 'md', className = '' }) {
  const sizes = { sm: 'w-4 h-4', md: 'w-8 h-8', lg: 'w-12 h-12' }
  return (
    <div className={`${sizes[size]} ${className} animate-spin`}>
      <svg viewBox="0 0 24 24" fill="none" className="w-full h-full">
        <circle
          cx="12" cy="12" r="10"
          stroke="currentColor" strokeWidth="3"
          className="opacity-20"
        />
        <path
          d="M12 2a10 10 0 0 1 10 10"
          stroke="currentColor" strokeWidth="3"
          strokeLinecap="round"
          className="text-sky-500"
        />
      </svg>
    </div>
  )
}

export function PageLoader() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <div className="text-center">
        <Spinner size="lg" className="mx-auto mb-4 text-white" />
        <p className="text-white/30 text-sm">Chargement...</p>
      </div>
    </div>
  )
}

export default Spinner
