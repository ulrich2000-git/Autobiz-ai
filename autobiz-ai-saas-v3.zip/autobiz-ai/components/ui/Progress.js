export function ProgressBar({ value, max, label, color = 'sky', showPercent = true }) {
  const percent = Math.min(100, (value / max) * 100)
  const colors = {
    sky: 'bg-sky-500',
    emerald: 'bg-emerald-500',
    yellow: 'bg-yellow-500',
    red: 'bg-red-500',
    violet: 'bg-violet-500',
  }
  return (
    <div>
      {label && (
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-white/50">{label}</span>
          {showPercent && <span className="text-xs font-medium text-white/70">{Math.round(percent)}%</span>}
        </div>
      )}
      <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${colors[color]}`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  )
}

export function UsageBar({ used, limit, label, unit = '' }) {
  const isUnlimited = limit === -1
  const percent = isUnlimited ? 0 : Math.min(100, (used / limit) * 100)
  const color = percent > 80 ? 'red' : percent > 60 ? 'yellow' : 'emerald'
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-xs text-white/50">{label}</span>
        <span className="text-xs font-medium text-white/70">
          {isUnlimited ? `${used}${unit} / ∞` : `${used}${unit} / ${limit}${unit}`}
        </span>
      </div>
      {!isUnlimited && (
        <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all duration-700 ${color === 'red' ? 'bg-red-500' : color === 'yellow' ? 'bg-yellow-500' : 'bg-emerald-500'}`}
            style={{ width: `${percent}%` }} />
        </div>
      )}
    </div>
  )
}
