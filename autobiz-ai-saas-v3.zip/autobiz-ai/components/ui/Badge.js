export function Badge({ children, variant = 'default', size = 'md' }) {
  const variants = {
    default: 'bg-white/10 text-white/60 border-white/15',
    blue: 'bg-sky-500/20 text-sky-300 border-sky-500/30',
    green: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    yellow: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    red: 'bg-red-500/20 text-red-300 border-red-500/30',
    purple: 'bg-violet-500/20 text-violet-300 border-violet-500/30',
  }
  const sizes = { sm: 'px-2 py-0.5 text-xs', md: 'px-2.5 py-0.5 text-xs' }
  return (
    <span className={`inline-flex items-center rounded-full font-semibold border ${variants[variant]} ${sizes[size]}`}>
      {children}
    </span>
  )
}
