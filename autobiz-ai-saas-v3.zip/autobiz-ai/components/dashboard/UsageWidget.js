import { useAuth } from '../../hooks/useAuth'
import { UsageBar } from '../ui/Progress'
import { PLANS } from '../../lib/stripe'

export default function UsageWidget() {
  const { userData } = useAuth()
  if (!userData) return null

  const planKey = (userData.plan || 'free').toUpperCase()
  const plan = PLANS[planKey] || PLANS.FREE
  const usage = userData.usage || {}

  const features = [
    { key: 'whatsappMessages', label: 'WhatsApp' },
    { key: 'contentGenerations', label: 'Contenu' },
    { key: 'salesAnalyses', label: 'Analyses' },
  ]

  return (
    <div className="space-y-3">
      {features.map(({ key, label }) => (
        <UsageBar
          key={key}
          label={label}
          used={usage[key] || 0}
          limit={plan.limits[key]}
        />
      ))}
    </div>
  )
}
