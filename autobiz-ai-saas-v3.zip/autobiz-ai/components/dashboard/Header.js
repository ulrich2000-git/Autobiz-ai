import { useAuth } from '../../hooks/useAuth'
import { Bell, Search, Zap } from 'lucide-react'
import { Badge } from '../ui/Badge'

export default function DashboardHeader({ title, subtitle }) {
  const { userData } = useAuth()
  const isPro = userData?.plan === 'pro'

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-8 py-4 bg-[#0a0a0f]/80 backdrop-blur-md border-b border-white/8">
      <div>
        <h1 className="text-2xl font-bold text-white" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
          {title}
        </h1>
        {subtitle && <p className="text-white/40 text-sm mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        {!isPro && (
          <a href="/app/billing" className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-sky-500/20 to-violet-500/20 border border-sky-500/30 rounded-xl text-sky-300 text-xs font-semibold hover:from-sky-500/30 hover:to-violet-500/30 transition-all">
            <Zap size={12} />
            Passer au Pro
          </a>
        )}
        <button className="relative p-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-colors">
          <Bell size={16} className="text-white/50" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-sky-500 rounded-full" />
        </button>
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-500 to-violet-500 flex items-center justify-center text-sm font-bold text-white">
          {userData?.email?.[0]?.toUpperCase() || 'U'}
        </div>
      </div>
    </header>
  )
}
