import { MessageSquare, PenTool, BarChart3, Zap } from 'lucide-react'

const iconMap = {
  whatsapp: { icon: MessageSquare, color: 'text-sky-400 bg-sky-500/10' },
  content: { icon: PenTool, color: 'text-violet-400 bg-violet-500/10' },
  sales: { icon: BarChart3, color: 'text-emerald-400 bg-emerald-500/10' },
  default: { icon: Zap, color: 'text-white/40 bg-white/5' },
}

function timeAgo(date) {
  const diff = Date.now() - new Date(date).getTime()
  const mins = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)
  if (mins < 1) return "À l'instant"
  if (mins < 60) return `il y a ${mins}m`
  if (hours < 24) return `il y a ${hours}h`
  return `il y a ${days}j`
}

export default function ActivityFeed({ activities = [] }) {
  if (!activities.length) {
    return (
      <div className="text-center py-8 text-white/30 text-sm">
        Aucune activité récente
      </div>
    )
  }
  return (
    <div className="space-y-1">
      {activities.map((activity, i) => {
        const { icon: Icon, color } = iconMap[activity.type] || iconMap.default
        return (
          <div key={i} className="flex items-start gap-3 p-3 rounded-xl hover:bg-white/3 transition-colors">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${color}`}>
              <Icon size={14} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white/70 text-sm">{activity.message}</p>
              {activity.detail && <p className="text-white/30 text-xs mt-0.5 truncate">{activity.detail}</p>}
            </div>
            <span className="text-white/25 text-xs flex-shrink-0">{timeAgo(activity.created_at)}</span>
          </div>
        )
      })}
    </div>
  )
}
