import { useRouter } from 'next/router'
import Link from 'next/link'
import { useAuth } from '../../hooks/useAuth'
import {
  LayoutDashboard, MessageSquare, PenTool, BarChart3,
  Settings, CreditCard, LogOut, Zap, ChevronRight
} from 'lucide-react'

const navItems = [
  { href: '/app', icon: LayoutDashboard, label: 'Vue d\'ensemble' },
  { href: '/app/chatbot', icon: MessageSquare, label: 'Chatbot WhatsApp' },
  { href: '/app/content', icon: PenTool, label: 'Contenu IA' },
  { href: '/app/sales', icon: BarChart3, label: 'Analyse Ventes' },
  { href: '/app/settings', icon: Settings, label: 'Paramètres' },
  { href: '/app/billing', icon: CreditCard, label: 'Facturation' },
]

export default function DashboardLayout({ children }) {
  const router = useRouter()
  const { user, userData, signOut } = useAuth()

  const handleSignOut = async () => {
    await signOut()
    router.push('/')
  }

  const isPro = userData?.plan === 'pro'

  const isActive = (href) => {
    if (href === '/app') return router.pathname === '/app'
    return router.pathname.startsWith(href)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex">
      {/* ── Sidebar ── */}
      <aside className="w-64 flex-shrink-0 min-h-screen bg-[#080810] border-r border-white/8 flex flex-col sticky top-0 h-screen overflow-y-auto">

        {/* Logo */}
        <div className="flex items-center gap-2.5 px-5 py-5 border-b border-white/8">
          <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg shadow-sky-500/30 flex-shrink-0">
            <Zap size={15} className="text-white" />
          </div>
          <Link href="/" className="text-lg font-extrabold text-white tracking-tight" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>
            AutoBiz <span className="text-sky-400">AI</span>
          </Link>
        </div>

        {/* Plan pill */}
        <div className="mx-3 mt-3">
          <div className={`px-3 py-2.5 rounded-xl border flex items-center justify-between ${
            isPro
              ? 'bg-sky-500/10 border-sky-500/25'
              : 'bg-white/3 border-white/8'
          }`}>
            <div>
              <p className="text-white/35 text-[10px] uppercase tracking-widest font-semibold">Plan</p>
              <p className={`text-sm font-bold ${isPro ? 'text-sky-300' : 'text-white/70'}`}>
                {isPro ? '⚡ Pro' : 'Gratuit'}
              </p>
            </div>
            {!isPro && (
              <Link href="/app/billing"
                className="text-[10px] font-bold text-sky-400 hover:text-sky-300 bg-sky-500/10 hover:bg-sky-500/20 px-2 py-1 rounded-lg transition-colors border border-sky-500/20">
                Upgrade
              </Link>
            )}
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-3 space-y-0.5">
          {navItems.map(({ href, icon: Icon, label }) => {
            const active = isActive(href)
            return (
              <Link key={href} href={href}
                className={`group flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                  active
                    ? 'bg-sky-500/15 text-white border border-sky-500/25 shadow-sm'
                    : 'text-white/45 hover:text-white/80 hover:bg-white/5'
                }`}>
                <Icon size={17} className={active ? 'text-sky-400' : 'text-current'} />
                <span>{label}</span>
                {active && <ChevronRight size={13} className="ml-auto text-sky-500/60" />}
              </Link>
            )
          })}
        </nav>

        {/* Divider */}
        <div className="mx-3 border-t border-white/8" />

        {/* User footer */}
        <div className="p-3">
          <div className="flex items-center gap-3 px-2 py-2 rounded-xl group">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-sky-500 to-violet-500 flex items-center justify-center text-sm font-bold text-white flex-shrink-0">
              {user?.email?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate leading-tight">
                {user?.email?.split('@')[0]}
              </p>
              <p className="text-xs text-white/35 truncate">{user?.email}</p>
            </div>
            <button
              onClick={handleSignOut}
              title="Se déconnecter"
              className="p-1.5 hover:bg-white/10 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
              <LogOut size={14} className="text-white/40" />
            </button>
          </div>
        </div>
      </aside>

      {/* ── Main ── */}
      <main className="flex-1 overflow-auto min-w-0">
        {children}
      </main>
    </div>
  )
}
