import Link from 'next/link'
import { MessageSquare, PenTool, BarChart3, ArrowRight } from 'lucide-react'

const actions = [
  {
    href: '/app/chatbot',
    icon: MessageSquare,
    label: 'Chatbot WhatsApp',
    description: 'Configurer les réponses automatiques',
    color: 'from-sky-500/20 to-blue-500/20',
    border: 'border-sky-500/20 hover:border-sky-500/40',
    iconColor: 'text-sky-400 bg-sky-500/10',
  },
  {
    href: '/app/content',
    icon: PenTool,
    label: 'Générer du contenu',
    description: 'Posts, emails, publicités en 1 clic',
    color: 'from-violet-500/20 to-purple-500/20',
    border: 'border-violet-500/20 hover:border-violet-500/40',
    iconColor: 'text-violet-400 bg-violet-500/10',
  },
  {
    href: '/app/sales',
    icon: BarChart3,
    label: 'Analyser les ventes',
    description: 'Insights et recommandations IA',
    color: 'from-emerald-500/20 to-teal-500/20',
    border: 'border-emerald-500/20 hover:border-emerald-500/40',
    iconColor: 'text-emerald-400 bg-emerald-500/10',
  },
]

export default function QuickActions() {
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {actions.map(({ href, icon: Icon, label, description, color, border, iconColor }) => (
        <Link key={href} href={href}
          className={`group relative overflow-hidden p-6 rounded-2xl border bg-gradient-to-br ${color} ${border} transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg`}>
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${iconColor}`}>
            <Icon size={20} />
          </div>
          <h3 className="text-white font-semibold mb-1" style={{fontFamily: 'Bricolage Grotesque, sans-serif'}}>{label}</h3>
          <p className="text-white/40 text-sm">{description}</p>
          <ArrowRight size={16} className="absolute bottom-5 right-5 text-white/20 group-hover:text-white/60 group-hover:translate-x-1 transition-all" />
        </Link>
      ))}
    </div>
  )
}
