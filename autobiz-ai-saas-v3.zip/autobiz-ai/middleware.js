import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

export async function middleware(req) {
  const res = NextResponse.next()
  const pathname = req.nextUrl.pathname

  // Vérification du token depuis le cookie de session Supabase
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  // Récupère le token depuis les cookies
  const cookieStore = req.cookies
  const accessToken =
    cookieStore.get('sb-access-token')?.value ||
    cookieStore.get(`sb-${supabaseUrl?.split('//')[1]?.split('.')[0]}-auth-token`)?.value

  const isLoggedIn = !!accessToken

  // Protéger /app/*
  if (pathname.startsWith('/app') && !isLoggedIn) {
    const loginUrl = new URL('/auth/login', req.url)
    loginUrl.searchParams.set('redirectTo', pathname)
    return NextResponse.redirect(loginUrl)
  }

  // Rediriger les utilisateurs connectés hors des pages auth
  if (pathname.startsWith('/auth') && isLoggedIn) {
    return NextResponse.redirect(new URL('/app', req.url))
  }

  return res
}

export const config = {
  matcher: [
    '/app/:path*',
    '/auth/:path*',
  ],
}
